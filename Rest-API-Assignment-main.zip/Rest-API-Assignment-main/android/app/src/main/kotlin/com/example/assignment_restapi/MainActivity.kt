package com.example.assignment_restapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
